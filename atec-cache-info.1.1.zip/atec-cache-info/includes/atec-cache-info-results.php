<?php
class atec_wpci_results
{
private function isPara() { if (isset($_GET['flush'])) return esc_html($_GET['flush']); else return false; }
private function enabled($enabled) { return '<font color="'.($enabled?'green':'red').'">'.($enabled?'enabled':'disabled').'</font>'; }
private function bsize($s) { foreach (array('','K','M','G') as $i => $k) { if ($s < 1024) break; $s/=1024; } return sprintf("%5.1f %sB",$s,$k); }
private function error($cache,$txt) { return '<font color="red">'.$cache.' '.$txt.'</font><script>document.getElementById("'.$cache.'_trash").style.display = "none";</script>'; }

function __construct()
{		
	global $wp_object_cache;
	$atec_wpci_key='atec_wpci_key';
	$pluginsUrl=plugins_url( '', __DIR__ );

	echo '<script>
	function atec_wpci_ac_reload() { const url = new URL(window.location.href); url.searchParams.delete("flush"); window.location.href=url; return false; };
	function atec_wpci_countDown(c) { ti=setTimeout(function() { atec_wpci_countDown(c+1); }, 1000); obj=document.getElementById("reload"); obj.innerHTML=obj.innerHTML+" "+(3-c)+" "; if (c>=2) { clearTimeout(ti); atec_wpci_ac_reload(); }};
	</script>';

	echo '<div style="width:99%; display:block;">';	
	echo '<h3 style="text-align: center;"><sub><img src="'.$pluginsUrl.'/assets/img/atec_wpci_icon.svg" style="height:22px;"></sub> atec Cache Info <font style="font-size:80%;">v'.wp_cache_get('atec_WPCI_version').'</font></h3>';

	if ($flush=$this->isPara())
	{
		echo '<center>Flushing '.$flush.' cache ... ';
		$result=false;
		switch ($flush) 
		{
			case 'OPcache': $result=opcache_reset(); break;
			case 'APCu': if (function_exists('apcu_clear_cache')) $result=apcu_clear_cache(); break;
			case 'Memcached': $m = new Memcached(); $m->addServer('localhost', 11211); $result=$m->flush(); break;
			case 'WP_ocache': $result=$wp_object_cache->flush(); break;
			case 'SQLite_ocache': $result=$wp_object_cache->flush(); break;
			case 'Redis': $redis = new Redis(); $redis->connect('127.0.0.1', 6379); $result=$redis->flushAll(); break;
		}
		if ($result==1) echo '<font color="green">successful</font>.';
		else echo '<font color="green">failed</font>.';
		echo '<br><a style="text-decoration:none;" href="#" onclick="return atec_wpci_ac_reload();">Please reload</a>.<br>... <span id="reload"></span>';
		echo '</center><script>atec_wpci_countDown(0)</script>';
		return;
	};

	include_once('server_info.php');

	$uri = sanitize_url($_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
	$uri = substr($uri, 0, strpos($uri, 'wp-admin/'));

	 $apcu_enabled=extension_loaded('apcu')  && apcu_enabled();
	 $memcached_enabled=class_exists('Memcached');
	 $opcache_enabled=function_exists('opcache_get_status') && is_array(opcache_get_status());
	 $redis_enabled=class_exists('redis');
	 $wp_enabled=is_object($wp_object_cache);
	global $sqlite_object_cache;
	 $sql_enabled=function_exists('sqlite_object_cache');

	 $requestUri=sanitize_url($_SERVER['REQUEST_URI']);

	echo '
	<div class="pure-g"><div class="pure-u-1-1" style="background: #e0e0e0; padding-left:5px; border:solid 1px #cbcbcb;"><h3 style="margin:10px 0;">Zend Opcode & WP Object Cache</h3></div></div>
	<div class="pure-g ac_inner-div">
		<div class="pure-u-1-4"><div class="ac_p">
			<h4>OPcache – '.$this->enabled($opcache_enabled).' '.($opcache_enabled?'<div id="pie_1" style="display:none;" class="ac_pie"></div>'.' <a href="'.$requestUri.'&flush=OPcache'.'" style="text-decoration:none; margin-left:5px;"><span class="dashicons dashicons-trash"></span></a>':'').'</h4>
			<hr>';

				if ($opcache_enabled)
				{
					$op_status=opcache_get_status();
					$op_conf=opcache_get_configuration();
					$total=$op_status['opcache_statistics']['hits']+$op_status['opcache_statistics']['misses']+0.001;
					$hits=$op_status['opcache_statistics']['hits']*100/$total;
					$misses=$op_status['opcache_statistics']['misses']*100/$total;
					$percent=$op_status['memory_usage']['used_memory']*100/$op_conf['directives']['opcache.memory_consumption'];
					$deg=round(360*$percent/100);
					echo '<style>#pie_1 { display:inline-block !important; background: conic-gradient( #ff7721 0deg '.$deg.'deg, white '.$deg.'deg 360deg ); }</style>';
					echo'
					<table class="pure-table">
					<tbody>
						<tr><td class="ac_b">Version:</td><td>'.$op_conf['version']['version'].'</td></tr>
						<tr><td class="ac_b">Memory:</td><td>'.$this->bsize($op_conf['directives']['opcache.memory_consumption']).'</td></tr>
						<tr><td class="ac_b">Used:</td><td>'.$this->bsize($op_status['memory_usage']['used_memory']).' '.sprintf(" (%.1f%%)",$percent).'</td></tr>
						<tr><td class="ac_b">Items:</td><td>'.number_format($op_status['opcache_statistics']['num_cached_scripts']+$op_status['opcache_statistics']['num_cached_keys']).'</td></tr>
						<tr><td class="ac_b">Hits:</td><td>'.number_format($op_status['opcache_statistics']['hits']).sprintf(" (%.1f%%)",$hits).'</td></tr>
						<tr><td class="ac_b">Misses:</td><td>'.number_format($op_status['opcache_statistics']['misses']).sprintf(" (%.1f%%)",$misses).'</td></tr>
						<tr><td colspan="2"><center style="font-size:60%; margin:0;">Hitrate</center><div class="ac_percent_div"><span class="ac_percent" style="width:'.round($hits).'%; background-color:green;"></span><span class="ac_percent" style="width:'.round($misses).'%; background-color:red;"></span></div></td></tr>
					</tbody>
					</table>';
					//echo '<pre>'.var_dump($op_status).'</pre>';
				}
				else echo 'Make sure opcache extension is installed and enabled in php.ini.';
				
		echo '
		</div></div>
		
		<div class="pure-u-1-4"><div class="ac_p">
			<h4>WP Object Cache – '.$this->enabled($wp_enabled).' '.($wp_enabled?' <a id="WP_ocache_trash" href="'.$requestUri.'&flush=WP_ocache'.'" style="text-decoration:none; margin-left:5px;"><span class="dashicons dashicons-trash"></span></a>':'').'</h4>	
			<hr>';
				//var_dump($wp_object_cache);
			if ($wp_enabled)
			{    	    
				if (method_exists('WP_Object_Cache', 'stats')) 
				{
					echo '<div id="stats" style="border:solid 1px #ccc; display:inline-block; padding:10px;">';
					$wp_object_cache->stats();
					echo '<style>#stats p { font-size:16px !important; margin:0; } .ac_p ul {display:none;}</style>';
					echo '</div><br><br>';
				}
				else
				{
					if (isset($wp_object_cache->cache_hits))
					{
						$total=$wp_object_cache->cache_hits+$wp_object_cache->cache_misses+0.001;
						$hits=$wp_object_cache->cache_hits*100/$total;
						$misses=$wp_object_cache->cache_misses*100/$total;
						echo'
						<table class="pure-table">
						<tbody>
							<tr><td class="ac_b">Hits:</td><td>'.number_format($wp_object_cache->cache_hits).sprintf(" (%.1f%%)",$hits).'</td></tr>
								<tr><td class="ac_b">Misses:</td><td>'.number_format($wp_object_cache->cache_misses).sprintf(" (%.1f%%)",$misses).'</td></tr>
								<tr><td colspan="2"><center style="font-size:60%; margin:0;">Hitrate</center><div class="ac_percent_div"><span class="ac_percent" style="width:'.round($hits).'%; background-color:green;"></span><span class="ac_percent" style="width:'.round($misses).'%; background-color:red;"></span></div></td></tr>
							</tbody>
						</table>';
						echo '<br>';
					};
				};
				
					wp_cache_set('$atec_wpci_key','hello');
					$temp=wp_cache_get('$atec_wpci_key');
					if ($temp=='hello')
					{
					wp_cache_delete('$atec_wpci_key');
					if (defined('LSCWP_OBJECT_CACHE') && LSCWP_OBJECT_CACHE=='true' && (method_exists('WP_Object_Cache', 'debug'))) 
					{
					$debug=$wp_object_cache->debug(); //var_dump($debug);
					preg_match('/\[total\]\s(\d+)\s/', $debug, $matches); $ls_total=(int) $matches[1];
					preg_match('/\[hit\]\s(\d+)\s/', $debug, $matches); $ls_hit=(int) $matches[1];
					preg_match('/\[miss\]\s(\d+)\s/', $debug, $matches); $ls_miss=(int) $matches[1];
						$total=$ls_hit+$ls_miss+0.001;
					$hits=$ls_hit*100/$total;
					$misses=$ls_miss*100/$total;
					echo ' 
						<table class="pure-table">
						<tbody>
							<tr><td class="ac_b">Items:</td><td>'.number_format($ls_total).'</td></tr>
							<tr><td class="ac_b">Hits:</td><td>'.number_format($ls_hit).sprintf(" (%.1f%%)",$hits).'</td></tr>
							<tr><td class="ac_b">Misses:</td><td>'.number_format($ls_miss).sprintf(" (%.1f%%)",$misses).'</td></tr>
							<tr><td colspan="2"><center style="font-size:60%; margin:0;">Hitrate</center><div class="ac_percent_div"><span class="ac_percent" style="width:'.round($hits).'%; background-color:green;"></span><span class="ac_percent" style="width:'.round($misses).'%; background-color:red;"></span></div></td></tr>
								</tbody>
						</table>';
					echo '<br>';
				};
				echo 'WP object cache is writeable.<br>';
				if ($apcu_enabled)
				{    
					if (function_exists('apcu_cache_info') && is_object(apcu_cache_info())) echo 'APCu cache is active.<br>Please see APCu statistics.<br>';
				};
				if (defined('LSCWP_V')) echo 'LiteSpeed cache v.'.LSCWP_V.' is active.<br>';

					}
				else echo $this->error('WP_ocache','not available.');
			}			
			else echo 'Check your wp-config.php for define("ENABLE_CACHE",TRUE).';
		
		echo '</div></div>    
	</div>
	<br><br>
	<div class="pure-g"><div class="pure-u-1-1" style="background: #e0e0e0; padding-left:5px; border:solid 1px #cbcbcb;"><h3 style="margin:10px 0;">Object Caches</h3></div></div>
	<div class="pure-g ac_inner-div">

		<div class="pure-u-1-4"><div class="ac_p">
			<h4>APCu – '.$this->enabled($apcu_enabled).' '.($apcu_enabled?'<div style="display:none;" id="pie_2" class="ac_pie"></div>'.' <a id="APCu_trash" href="'.$requestUri.'&flush=APCu'.'" style="text-decoration:none; margin-left:5px;"><span class="dashicons dashicons-trash"></span></a>':'').'</h4>
			<hr>';
			$url=$uri.'wp-admin/plugin-install.php?s=apcu-manager%2520PerfOps%2520One&tab=search&type=term';
			$link='<a href="'.$url.'">APCu Manager</a>';	    
			if ($apcu_enabled)
			{    
				$apcu_cache=apcu_cache_info(true);
				if ($apcu_cache)
				{
					$apcu_mem=apcu_sma_info();
					$total=$apcu_cache['num_hits']+$apcu_cache['num_misses']+0.001;
					$hits=$apcu_cache['num_hits']*100/$total;
					$misses=$apcu_cache['num_misses']*100/$total;
					$percent=$apcu_cache['mem_size']*100/($apcu_mem['num_seg']*$apcu_mem['seg_size']);
					$deg=round(360*$percent/100);	
					echo '<style>#pie_2 { display:inline-block !important; background: conic-gradient( #ff7721 0deg '.$deg.'deg, white '.$deg.'deg 360deg ); }</style>';
					echo'
					<table class="pure-table">
					<tbody>
					<tr><td class="ac_b">Version:</td><td>'.phpversion('apcu').'</td></tr>
					<tr><td class="ac_b">Type:</td><td>'.$apcu_cache['memory_type'].'</td></tr>
					<tr><td class="ac_b">Memory:</td><td>'.$this->bsize($apcu_mem['num_seg']*$apcu_mem['seg_size']).'</td></tr>';
					if ($percent>0)
					{
						echo '
						<tr><td class="ac_b">Used:</td><td>'.$this->bsize($apcu_cache['mem_size']).' '.sprintf(" (%.1f%%)",$percent).'</td></tr>
						<tr><td class="ac_b">Items:</td><td>'.number_format($apcu_cache['num_entries']).'</td></tr>
						<tr><td class="ac_b">Hits:</td><td>'.number_format($apcu_cache['num_hits']).sprintf(" (%.1f%%)",$hits).'</td></tr>
						<tr><td class="ac_b">Misses:</td><td>'.number_format($apcu_cache['num_misses']).sprintf(" (%.1f%%)",$misses).'</td></tr>
						<tr><td colspan="2"><center style="font-size:60%; margin:0;">Hitrate</center><div class="ac_percent_div"><span class="ac_percent" style="width:'.round($hits).'%; background-color:green;"></span><span class="ac_percent" style="width:'.round($misses).'%; background-color:red;"></span></div></td></tr>
						</tbody>
						</table>';
						}
					else 
					{
						echo '</tbody></table><br>Not in use.<br>Please enable '.$link.'.';
						echo '<script>document.getElementById("APCu_trash").style.display = "none";</script>';
					}
				}
				else echo $this->error('APCu','cache data could not be retrieved.');
			}
			else echo 'Make sure apcu extension is installed and enabled in php.ini.<br>Install '.$link.'.';		    

		echo '</div></div>
		
		<div class="pure-u-1-4"><div class="ac_p">
			<h4>Memcached – '.$this->enabled($memcached_enabled).' '.($memcached_enabled?'<div id="pie_3" style="display:none;" class="ac_pie"></div>'.' <a id="Memcached_trash" href="'.$requestUri.'&flush=Memcached'.'" style="text-decoration:none; margin-left:5px;"><span class="dashicons dashicons-trash"></span></a>':'').'</h4>	
			<hr>';
		
			if ($memcached_enabled)
			{    	    
				$m = new Memcached();
				$m->addServer('localhost', 11211);
				$mem=$m->getStats();
				if ($mem)
				{
					$mem=$mem['localhost:11211'];
					$total=$mem['get_hits']+$mem['get_misses']+0.001;
					$hits=$mem['get_hits']*100/$total;
					$misses=$mem['get_misses']*100/$total;			
					$percent=$mem['bytes']*100/($mem['limit_maxbytes']);
					$deg=round(360*$percent/100);	
					echo '<style>#pie_3 { display:inline-block !important; background: conic-gradient( #ff7721 0deg '.$deg.'deg, white '.$deg.'deg 360deg ); }</style>';
					echo'
					<table class="pure-table">
					<tbody>
						<tr><td class="ac_b">Version:</td><td>'.$mem['version'].'</td></tr>';
						if (isset($mem['limit_maxbytes'])) echo '<tr><td class="ac_b">Memory:</td><td>'.$this->bsize($mem['limit_maxbytes']).'</td></tr>';
						if (isset($mem['bytes'])) echo '<tr><td class="ac_b">Used:</td><td>'.$this->bsize($mem['bytes']).' '.sprintf(" (%.1f%%)",$percent).'</td></tr>';
						if (isset($mem['total_items'])) echo '<tr><td class="ac_b">Items:</td><td>'.number_format($mem['total_items']).'</td></tr>';
						echo '<tr><td class="ac_b">Hits:</td><td>'.number_format($mem['get_hits']).sprintf(" (%.1f%%)",$hits).'</td></tr>
						<tr><td class="ac_b">Misses:</td><td>'.number_format($mem['get_misses']).sprintf(" (%.1f%%)",$misses).'</td></tr>
						<tr><td colspan="2"><center style="font-size:60%; margin:0;">Hitrate</center><div class="ac_percent_div"><span class="ac_percent" style="width:'.round($hits).'%; background-color:green;"></span><span class="ac_percent" style="width:'.round($misses).'%; background-color:red;"></span></div></td></tr>
						</tbody>
					</table>';
					$m->set('$atec_wpci_key','hello');
					$temp=$m->get('$atec_wpci_key');
					$m->delete($atec_wpci_key);
					if ($temp=='hello') echo '<br>Memcached is writeable.';
				}
				else echo $this->error('Memcached','status not available.');
			}			
			else echo 'Make sure memcached extension is installed.<br>Server should listen on localhost:11211.';
		
		echo '</div></div>
		
		<div class="pure-u-1-4"><div class="ac_p">
			<h4>Redis – '.$this->enabled($redis_enabled).' '.($redis_enabled?' <a id="Redis_trash" href="'.$requestUri.'&flush=Redis'.'" style="text-decoration:none; margin-left:5px;"><span class="dashicons dashicons-trash"></span></a>':'').'</h4>	
			<hr>';
			
				if ($redis_enabled)
				{    	    
				if (class_exists('Redis'))
				{
					$redis = new Redis();
					try
					{ 
						$redis->connect('localhost', 6379);
						if (is_object($redis))
						{					
							$server=$redis->info('server');

							$fp = @fsockopen('localhost',6379, $errno, $errstr, 30);
							$data = array();
							if (!$fp) { echo $this->error('Redis','socked connection failed.<br>'); } 
							else 
							{
									@fwrite($fp, "INFO\r\nQUIT\r\n");
									while (!feof($fp)) 
									{
									$info = explode(':', trim(fgets($fp)), 2);
									if (isset($info[1])) $data[$info[0]] = $info[1];
									}
									fclose($fp);

									$total=$data['keyspace_hits']+$data['keyspace_misses']+0.001;
								$hits=$data['keyspace_hits']*100/$total;
								$misses=$data['keyspace_misses']*100/$total;
								
								echo'
								<table class="pure-table">
								<tbody>
									<tr><td class="ac_b">Version:</td><td>'.$server['redis_version'].'</td></tr>
									<tr><td class="ac_b">Memory used:</td><td>'.$this->bsize($data['used_memory']).'</td></tr>
									<tr><td class="ac_b">Hits:</td><td>'.number_format($data['keyspace_hits']).sprintf(" (%.1f%%)",$hits).'</td></tr>
										<tr><td class="ac_b">Misses:</td><td>'.number_format($data['keyspace_misses']).sprintf(" (%.1f%%)",$misses).'</td></tr>
										<tr><td colspan="2"><center style="font-size:60%; margin:0;">Hitrate</center><div class="ac_percent_div"><span class="ac_percent" style="width:'.round($hits).'%; background-color:green;"></span><span class="ac_percent" style="width:'.round($misses).'%; background-color:red;"></span></div></td></tr>
										</tbody>
								</table>';
							}
						};
						$redis->setex('$atec_wpci_key', 3600, 'hello');
						$temp=$redis->get('$atec_wpci_key');
						$redis->del('$atec_wpci_key');
						if ($temp=='hello') echo '<br>Redis is writeable.';
						}
						catch (Exception $e)
						{ 
						echo $this->error('Redis','connection failed.<br>'.$e->getMessage().'.');
						} 
				}
				else echo $this->error('Redis','class not available.');
				}
				else echo 'Make sure redis extension is installed.<br>Server should listen on localhost:6378.';
		
		echo '</div></div>
		
			<div class="pure-u-1-4"><div class="ac_p">
			<h4>SQLite object cache– '.$this->enabled($sql_enabled).' '.($sql_enabled?' <a id="SQLite_ocache_trash" href="'.$requestUri.'&flush=SQLite_ocache'.'" style="text-decoration:none; margin-left:5px;"><span class="dashicons dashicons-trash"></span></a>':'').'</h4>	
			<hr>';
			
					//var_dump(SQLite_Object_Cache());
				if ($sql_enabled)
				{    	   
					$total=$wp_object_cache->cache_hits+$wp_object_cache->cache_misses+0.001;
					$hits=$wp_object_cache->cache_hits*100/$total;
					$misses=$wp_object_cache->cache_misses*100/$total;
				echo'
				<table class="pure-table">
				<tbody>
					<tr><td class="ac_b">Version:</td><td>'.SQLite_Object_Cache()->_version.'</td></tr>
					<tr><td class="ac_b">Hits:</td><td>'.number_format($wp_object_cache->cache_hits).sprintf(" (%.1f%%)",$hits).'</td></tr>
						<tr><td class="ac_b">Misses:</td><td>'.number_format($wp_object_cache->cache_misses).sprintf(" (%.1f%%)",$misses).'</td></tr>
						<tr><td colspan="2"><center style="font-size:60%; margin:0;">Hitrate</center><div class="ac_percent_div"><span class="ac_percent" style="width:'.round($hits).'%; background-color:green;"></span><span class="ac_percent" style="width:'.round($misses).'%; background-color:red;"></span></div></td></tr>
						</tbody>
				</table>';
				}
				else 
				{
					$url=$uri.'wp-admin/plugin-install.php?s=SQLite%2520Object%2520Cache%2520oliver%2520jones&tab=search&type=term';
					echo 'Install <a href="'.$url.'">SQLite object cache</a>.';
			}
		
		echo '</div></div>

	</div>

	<br><br>';

	echo '<table class="pure-table" style="width:100%;">
		<thead>
			<tr><td class="ac_b">PHP Extensions</td></tr>
		</thead>
		<tbody></tbody>
			<tr><td>';

				$arr=get_loaded_extensions();
				sort($arr);
				foreach ($arr as $a) 
				{ 
					$array = array('Zend OPcache','apcu','memcached','redis','sqlite3');
					if (str_replace($array, '', $a) !== $a) { echo '<font style="font-weight:bold;" color="green">'; }
					else echo '<font>';
					echo(esc_html($a)." | ");
					echo '</font>';
				};

			echo '</td></tr>
		</tbody>
	</table>

	<center><p style="font-size:80%;">© 2023 by <a href="https://atec-systems.com/" target="_blank" style="text-decoration: none;">atec-systems.com</a></p></center>

	</div>
	';
}
};
$atec_wpci_results = new atec_wpci_results;
?>