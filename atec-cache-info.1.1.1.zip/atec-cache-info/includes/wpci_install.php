<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

wp_cache_set('atec_WPCI_version','1.1.1');

add_action('admin_menu', 'atec_wpci_menu');
function atec_wpci_menu() 
{ 
  $pluginDir=plugin_dir_path(__DIR__).'assets/img/';
  $svg=file_get_contents($pluginDir.'atec_wpci_icon.svg');
  $svg=str_replace('#000000','#fff',$svg);
  $base64=base64_encode($svg);
  
    add_menu_page( 
      'atec Cache Info - Dashboard', 
      'atec Cache Info', 
      'manage_options', 
      'atec_wpci', 
      'atec_wpci', 
      'data:image/svg+xml;base64,'.esc_html($base64)
     );
}

function atec_wpci() { include_once(plugin_dir_path(__DIR__).'includes/atec-cache-info-results.php'); }

function atec_wpci_styles()
{
	$pluginDir=plugin_dir_url( __DIR__ ).'assets/css/';
	wp_register_style('atec_wpci_pure', $pluginDir.'pure-min.css' ); wp_enqueue_style( 'atec_wpci_pure' );
	wp_register_style('atec_wpci_style', $pluginDir.'atec_wpci_style.min.css' ); wp_enqueue_style( 'atec_wpci_style' );
}
add_action( 'admin_enqueue_scripts', 'atec_wpci_styles' );
?>
