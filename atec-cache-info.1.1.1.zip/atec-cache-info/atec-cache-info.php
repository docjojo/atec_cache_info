<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
  /**
  * Plugin Name:  atec Cache Info
  * Plugin URI: https://atec-systems.com/
  * Description: atec Cache Info & Statistics (OPcache, WP-object-cache, APCu, Memcached, Redis and SQLite-object-cache )
  * Version: 1.1.1
  * Author: Chris Ahrweiler
  * Author URI: https://atec-systems.com
  * License: GPL2
  * License URI:  https://www.gnu.org/licenses/gpl-2.0.html
  * Text Domain:  atec-cache-info
  */
  
if (is_admin()) require_once(__DIR__.'/includes/wpci_install.php');
?>
